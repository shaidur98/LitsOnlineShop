<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_login_controller extends CI_Controller {

public function check_user_login(){

$email=$this->input->post('email',true);
$password=$this->input->post('password',true);
$result=$this->UserLoginModel->check_user_login_info($email,$password);

//echo'<pre>';
//print_r($result);
//echo'</pre>';

//exit();
}


}// End of class User_login
