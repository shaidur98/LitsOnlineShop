								<!-- category-list-pro start -->
								<div class="category-list-pro sidebar-list">
									<h3>Products At a Glance</h3>
									<ul>
										<li><a href="<?php echo site_url('cs/all_product');?>">All Products</a><span>8</span></li>
										<li><a href="<?php echo site_url('cs/new_product');?>">New Products</a><span>3</span></li>
										<li><a href="<?php echo site_url('cs/offered_product');?>">Offered Products</a><span>4</span></li>
										<li><a href="<?php echo site_url('cs/brand_product');?>">Brand products</a><span>7</span></li>
										<li><a href="#">New Brand Products</a><span>2</span></li>
									</ul>
								</div>
								<!-- category-list-pro end -->